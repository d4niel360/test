


#import
import asyncio
import pygame



#GLOBAL_FONCTIONS:
def pygame_display_set_mode(args1, args2):
    global pygame_screen
    pygame_screen = pygame.display.set_mode((args1, args2))
def pygame_time_Clock():
    global pygame_clock
    pygame_clock = pygame.time.Clock()



#GLOBAL_VARIABLES:
pygame_screen = None
pygame_clock = int(0)
pygame_running = False

#SCRIPTS:


#_PYGAME_:
async def PYGAME():
    global pygame_running
    global pygame_screen
    global pygame_clock
    pygame_running = True
    while pygame_running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame_running = False


        pygame.display.flip()

        pygame_clock.tick(60)
        await asyncio.sleep(0)


#_START_:
async def START():
    global pygame_running
    global pygame_screen
    pygame.init()
    pygame_display_set_mode(800, 600)
    pygame_time_Clock()
    pygame_screen.fill((0, 0, 0))
    asyncio.create_task(PYGAME())
    pygame.draw.rect(pygame_screen, (255, 0, 0), (100, 100, 50, 50))
    await asyncio.sleep(5)
    pygame_running = False

    await asyncio.sleep(0)





#START:
if __name__ == "__main__":
    asyncio.run(START())